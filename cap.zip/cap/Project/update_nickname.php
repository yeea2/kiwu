<?php
header('Content-Type: application/json; charset=utf-8');

// DB 연결
$host = 'localhost';
$user = 'root';
$pass = '';          // 비밀번호 있으면 여기 입력
$db   = 'capstone';  // 네가 쓰는 DB 이름

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode([
        'success' => false,
        'message' => 'DB 연결 실패: ' . $conn->connect_error
    ]);
    exit;
}

// JS에서 보낸 JSON 읽기
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

$username = $data['id'] ?? '';
$nickname = $data['nickname'] ?? '';

if ($username === '' || $nickname === '') {
    echo json_encode([
        'success' => false,
        'message' => '필요한 데이터가 없습니다.'
    ]);
    exit;
}

// 닉네임 업데이트
$stmt = $conn->prepare("UPDATE members SET nickname = ? WHERE username = ?");
$stmt->bind_param("ss", $nickname, $username);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode([
            'success' => true,
            'message' => '닉네임이 성공적으로 변경되었습니다.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => '해당 아이디를 찾을 수 없습니다.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => '닉네임 업데이트 실패: ' . $conn->error
    ]);
}

$stmt->close();
$conn->close();
