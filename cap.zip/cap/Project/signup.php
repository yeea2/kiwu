<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'capstone';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'DB 연결 실패: ' . $conn->connect_error],
                     JSON_UNESCAPED_UNICODE);
    exit;
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

$id = isset($data['id']) ? trim($data['id']) : '';
$pw = isset($data['pw']) ? trim($data['pw']) : '';

if ($id === '' || $pw === '') {
    echo json_encode(['success' => false, 'message' => '아이디와 비밀번호를 모두 입력해주세요.'],
                     JSON_UNESCAPED_UNICODE);
    exit;
}

// 아이디 중복 확인
$stmt = $conn->prepare("SELECT id FROM members WHERE username = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => '이미 사용 중인 아이디입니다.'],
                     JSON_UNESCAPED_UNICODE);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// 회원 저장
$stmt = $conn->prepare("INSERT INTO members (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $id, $pw);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => '회원가입이 완료되었습니다.'],
                     JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['success' => false, 'message' => '회원가입 실패: ' . $stmt->error],
                     JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
