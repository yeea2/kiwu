-- 1. 데이터베이스 생성
CREATE DATABASE IF NOT EXISTS capstone
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

-- 2. 데이터베이스 선택
USE capstone;

-- 3. 기존 members 테이블이 있다면 삭제 (원하면 살려둬도 됨)
DROP TABLE IF EXISTS members;

-- 4. members 테이블 생성 (username 8~15자용 VARCHAR(15))
CREATE TABLE IF NOT EXISTS members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(15) NOT NULL UNIQUE,
    password VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_general_ci;

-- 5. (선택) 테스트 계정
-- INSERT INTO members (username, password) VALUES ('002SoftWare', '비밀번호');

-- 6. 구조 확인
DESCRIBE members;

-- 7. 데이터 확인
SELECT * FROM members;
