
        const players = [
               { name: 'USERNAME_01', time: '2:45', score: 458, rank: 1, image: './images/profile.png' },
    { name: 'USERNAME_02', time: '3:12', score: 458, rank: 2, image: 'static/images/user2.png' },
    { name: 'USERNAME_03', time: '3:55', score: 458, rank: 3, image: 'static/images/user3.png' },
    { name: 'USERNAME_04', time: '4:20', score: 458, rank: 4, image: 'static/images/user4.png' },
    { name: 'USERNAME_05', time: '5:10', score: 458, rank: 5, image: 'static/images/user5.png' },
    { name: 'USERNAME_06', time: '6:05', score: 458, rank: 6, image: 'static/images/user6.png' }
        ];

        const medals = ['🥇', '🥈', '🥉'];
        const clockIcon = '⏱️';
        const starIcon = '⭐';

        function getMedalForRank(rank) {
            if (rank <= 3) {
                return medals[rank - 1];
            }
            return '';
        }

        function getAvatarLetter(name) {
            return name.charAt(0).toUpperCase();
        }

        function getAvatarColor(index) {
            const colors = [
                'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
                'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
                'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
                'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
                'linear-gradient(135deg, #30cfd0 0%, #330867 100%)'
            ];
            return colors[index % colors.length];
        }

        function getRankClass(rank) {
            if (rank === 1) return 'rank-1';
            if (rank === 2) return 'rank-2';
            if (rank === 3) return 'rank-3';
            return 'rank-other';
        }

        function renderRanking() {
            const rankingList = document.getElementById('rankingList');
            rankingList.innerHTML = players.map((player, index) => {
                const medal = getMedalForRank(player.rank);
                const rankClass = getRankClass(player.rank);

                return `
                    <div class="ranking-item ${rankClass}">
                        <div class="medal-icon">${medal || `<span style="font-size: 32px;">${player.rank}</span>`}</div>
                        <img src="${player.image}" alt="${player.name}" class="player-avatar">
                        <div class="player-info">
                            <div class="player-name">${player.name}</div>
                            <div class="player-stats">
                                <div class="stat-item">
                                    <span class="stat-icon">${starIcon}</span>
                                    <span>${player.score}</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-icon">${clockIcon}</span>
                                    <span>${player.time}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

       document.querySelector('.close-btn').addEventListener('click', () => {
        window.location.href = 'main.html';
    });

        renderRanking();