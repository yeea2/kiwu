// 필요한 패키지들 불러오기
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");
const session = require("express-session");
const path = require("path");

// 🚨 경로 수정: config.js 파일이 server.js와 같은 mainPage 폴더에 있다고 가정합니다.
const { local, production } = require("./config"); 

const app = express();
const PORT = process.env.PORT || 3000;

// 환경 구분 (로컬/배포)
const dbConfig = process.env.NODE_ENV === "production" ? production : local;
const db = mysql.createConnection(dbConfig);

// CORS 설정 및 body-parser 사용
app.use(cors());
app.use(bodyParser.json());

// 💡 1. mainPage 폴더를 정적 파일로 등록 (기존)
app.use(express.static(__dirname)); 

// ✅ 2. gamePage 폴더를 정적 파일로 등록 (404 에러 해결 코드)
// __dirname (mainPage)에서 상위(..)로 이동 후 gamePage 폴더를 정적 파일로 등록
app.use('/gamePage', express.static(path.join(__dirname, '..', 'gamePage')));


// ✅ 세션 설정 (쿠키 설정 포함)
app.use(session({
    secret: "capstone_secret",  // 세션에 사용할 비밀 키
    resave: false,              // 세션을 강제로 다시 저장하지 않음
    saveUninitialized: true,    // 세션을 초기화된 상태로 저장
    cookie: {
        secure: process.env.NODE_ENV === "production",  // HTTPS에서만 쿠키를 사용
        sameSite: 'lax',
        maxAge: 1000 * 60 * 60 * 24  // 쿠키 만료 시간 (24시간)
    }
}));

// DB 연결 확인
db.connect(err => {
    if (err) {
        console.error("❌ MySQL 연결 실패:", err);
    } else {
        console.log("✅ MySQL 연결 성공");
    }
});

// 회원가입 처리
app.post("/signup", (req, res) => {
    const { id, pw } = req.body;

    // 아이디와 비밀번호가 모두 있는지 확인
    if (!id || !pw) {
        return res.status(400).json({ success: false, message: "아이디와 비밀번호를 입력해 주세요." });
    }

    // 비밀번호 길이 체크 (추가 검증 로직)
    if (pw.length < 4 || pw.length > 10) {
        return res.status(400).json({ success: false, message: "비밀번호는 4~10자 사이여야 합니다." });
    }

    // 💡 DB 쿼리 수정: users -> members, id -> username
    const query = "INSERT INTO members (username, password) VALUES (?, ?)";
    db.query(query, [id, pw], (err, result) => {
        if (err) {
            console.error("회원가입 오류:", err);
            // 중복 키 에러 (ER_DUP_ENTRY) 처리 추가 (선택 사항이지만 유용)
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(409).json({ success: false, message: "이미 사용 중인 아이디입니다." });
            }
            return res.status(500).json({ success: false, message: "회원가입 중 오류가 발생했습니다." });
        }

        // 회원가입 성공
        res.json({ success: true, message: "회원가입이 완료되었습니다." });
    });
});

// 로그인 처리
app.post("/login", (req, res) => {
    const { id, pw } = req.body;

    // 💡 DB 쿼리 수정: users -> members, id -> username
    const query = "SELECT * FROM members WHERE username = ? AND password = ?";
    db.query(query, [id, pw], (err, results) => {
        if (err) {
            console.error("로그인 오류:", err);
            return res.status(500).json({ success: false, message: "로그인 중 오류가 발생했습니다." });
        }

        if (results.length > 0) {
            req.session.userId = id;  // 로그인 성공 시 세션에 사용자 ID 저장
            res.json({ success: true, message: "로그인되었습니다." });
        } else {
            res.status(401).json({ success: false, message: "아이디나 비밀번호가 잘못되었습니다." });
        }
    });
});

// 로그아웃 처리
app.post("/logout", (req, res) => {
    req.session.destroy();  // 세션 삭제
    res.json({ success: true, message: "로그아웃되었습니다." });
});

// 로그인 상태 확인
app.get("/session", (req, res) => {
    if (req.session.userId) {
        res.json({ loggedIn: true, userId: req.session.userId });
    } else {
        res.json({ loggedIn: false });
    }
});

// HTML 파일 제공 (세션 및 JSON 응답 처리)
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "main.html")));
app.get("/login.html", (req, res) => res.sendFile(path.join(__dirname, "login.html")));
app.get("/profile.html", (req, res) => res.sendFile(path.join(__dirname, "profile.html")));
app.get("/rank.html", (req, res) => res.sendFile(path.join(__dirname, "rank.html")));


// 서버 시작
app.listen(PORT, () => {
    console.log(`🚀 서버 실행 중: http://localhost:${PORT}`);
});