// login_db.js - 서버와 통신하는 로그인 시스템

// 쿠키 관련 함수
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/; SameSite=Lax";
}

function getCookie(name) {
    const searchName = name + '=';
    const decodedCookie = decodeURIComponent(document.cookie);
    const cookieArray = decodedCookie.split(';');

    for (let i = 0; i < cookieArray.length; i++) {
        let cookie = cookieArray[i].trim();
        if (cookie.indexOf(searchName) === 0) {
            return cookie.substring(searchName.length, cookie.length);
        }
    }
    return null;
}

// 회원가입 처리
async function handleSignup(event) {
    event.preventDefault();

    // 에러 메시지 초기화
    document.getElementById('signupIdError').textContent = '';
    document.getElementById('signupPasswordError').textContent = '';
    document.getElementById('signupPasswordConfirmError').textContent = '';

    const name = document.getElementById('signupName').value.trim();
    const userId = document.getElementById('signupId').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPassword').value;
    const passwordConfirm = document.getElementById('signupPasswordConfirm').value;

    // 클라이언트 사이드 검증
    if (userId.length < 5 || userId.length > 15) {
        document.getElementById('signupIdError').textContent = '아이디는 5~15자 사이여야 합니다.';
        return;
    }

    if (password.length < 4 || password.length > 10) {
        document.getElementById('signupPasswordError').textContent = '비밀번호는 4~10자 사이여야 합니다.';
        return;
    }

    if (password !== passwordConfirm) {
        document.getElementById('signupPasswordConfirmError').textContent = '비밀번호가 일치하지 않습니다.';
        return;
    }

    try {
        const response = await fetch('../signup.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: userId,
                pw: password
            })
        });


        const data = await response.json();

        if (data.success) {
            // localStorage에도 추가 정보 저장 (프로필용)
            const users = JSON.parse(localStorage.getItem('users') || '[]');
            users.push({
                name: name,
                userId: userId,
                email: email,
                password: password,
                joinDate: new Date().toISOString()
            });
            localStorage.setItem('users', JSON.stringify(users));

            document.getElementById('signupSuccess').textContent = '✅ ' + data.message;

            // 폼 초기화 후 로그인 페이지로
            setTimeout(() => {
                document.getElementById('signupSuccess').textContent = '';
                event.target.reset();
                switchForm();
            }, 1500);
        } else {
            if (data.message.includes('이미 사용 중')) {
                document.getElementById('signupIdError').textContent = data.message;
            } else {
                document.getElementById('signupPasswordError').textContent = data.message;
            }
        }
    } catch (error) {
        console.error('회원가입 오류:', error);
        alert('회원가입 중 오류가 발생했습니다. 서버가 실행중인지 확인해주세요.');
    }
}

/// 로그인 처리
async function handleLogin(event) {
    event.preventDefault();

    // 에러 메시지 초기화
    document.getElementById('loginPasswordError').textContent = '';

    const userId = document.getElementById('loginId').value.trim();
    const password = document.getElementById('loginPassword').value;
    const rememberMe = document.getElementById('rememberMe').checked;

    // ✅ 아이디 5~15자 검사로 변경
    if (userId.length < 5 || userId.length > 15) {
        document.getElementById('loginPasswordError').textContent = '아이디는 5~15자 사이여야 합니다.';
        return;
    }

    // 비밀번호는 그대로 4~10자
    if (password.length < 4 || password.length > 10) {
        document.getElementById('loginPasswordError').textContent = '비밀번호는 4~10자 사이여야 합니다.';
        return;
    }

    try {
        // ✅ PHP 파일로 보내기
        const response = await fetch('../login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: userId,
                pw: password
            })
        });


        const data = await response.json();

        if (data.success) {
            // 로그인 성공
            setCookie('loggedIn', 'true', rememberMe ? 7 : 1); // 아이디 저장 체크 시 7일, 아니면 1일

            // localStorage에서 사용자 정보 찾기
            const users = JSON.parse(localStorage.getItem('users') || '[]');
            let user = users.find(u => u.userId === userId);

            if (!user) {
                // localStorage에 없으면 기본 정보 생성
                user = {
                    name: userId,
                    userId: userId,
                    email: userId + '@example.com',
                    password: password,
                    joinDate: new Date().toISOString()
                };
                users.push(user);
                localStorage.setItem('users', JSON.stringify(users));
            }

            localStorage.setItem('currentUser', JSON.stringify(user));

            // 아이디 저장 처리
            if (rememberMe) {
                localStorage.setItem('savedUserId', userId);
            } else {
                localStorage.removeItem('savedUserId');
            }

            document.getElementById('loginSuccess').textContent = '✅ ' + data.message;

            setTimeout(() => {
                // 메인 페이지 표시 또는 main.html로 이동
                if (document.getElementById('mainPage')) {
                    showMainPage();
                } else {
                    window.location.href = 'main.html';
                }
            }, 1000);
        } else {
            document.getElementById('loginPasswordError').textContent = data.message;
        }
    } catch (error) {
        console.error('로그인 오류:', error);
        alert('로그인 중 오류가 발생했습니다. 서버가 실행중인지 확인해주세요.');
    }
}

// 로그아웃 처리
async function logout() {
    try {
        // ✅ PHP 로그아웃
        const response = await fetch('../logout.php', {
            method: 'POST'
        });



        const data = await response.json();

        // 쿠키 삭제
        setCookie('loggedIn', '', -1);

        // localStorage 정리
        localStorage.removeItem('currentUser');

        alert(data.message);

        // 로그인 페이지로 이동
        if (document.getElementById('mainPage')) {
            document.getElementById('mainPage').classList.add('hidden');
            document.getElementById('authContainer').classList.remove('hidden');
            document.getElementById('loginForm').classList.remove('hidden');
            document.getElementById('signupForm').classList.add('hidden');

            // 폼 초기화
            document.getElementById('loginPassword').value = '';
            const savedUserId = localStorage.getItem('savedUserId');
            if (savedUserId) {
                document.getElementById('loginId').value = savedUserId;
                document.getElementById('rememberMe').checked = true;
            }
        } else {
            window.location.href = 'login.html';
        }
    } catch (error) {
        console.error('로그아웃 오류:', error);
        alert('로그아웃 중 오류가 발생했습니다.');
    }
}

// 메인 페이지 표시
function showMainPage() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    if (currentUser) {
        document.getElementById('authContainer').classList.add('hidden');
        document.getElementById('forgotPasswordContainer').classList.add('hidden');
        document.getElementById('mainPage').classList.remove('hidden');

        // 사용자 정보 표시
        document.getElementById('displayUserName').textContent = currentUser.name;
        document.getElementById('infoName').textContent = currentUser.name;
        document.getElementById('infoId').textContent = currentUser.userId;
        document.getElementById('infoEmail').textContent = currentUser.email;

        // 가입일 표시
        if (currentUser.joinDate) {
            const joinDate = new Date(currentUser.joinDate);
            document.getElementById('infoDate').textContent = joinDate.toLocaleDateString('ko-KR');
        }
    }
}

// 폼 전환
function switchForm() {
    document.getElementById('loginForm').classList.toggle('hidden');
    document.getElementById('signupForm').classList.toggle('hidden');

    // 에러 메시지 및 성공 메시지 초기화
    document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
    document.querySelectorAll('.success-message').forEach(el => el.textContent = '');
}

// 비밀번호 표시/숨김
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const button = event.target.closest('.password-toggle');

    if (input.type === 'password') {
        input.type = 'text';
        button.textContent = '🙈';
    } else {
        input.type = 'password';
        button.textContent = '👁️';
    }
}

// 아이디 찾기
function showFindId() {
    document.getElementById('authContainer').classList.add('hidden');
    document.getElementById('findIdContainer').classList.remove('hidden');
}

function handleFindId(event) {
    event.preventDefault();

    const email = document.getElementById('findIdEmail').value;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email);

    if (user) {
        document.getElementById('findIdSuccess').textContent = '✅ 아이디를 찾았습니다!';
        document.getElementById('foundIdValue').textContent = user.userId;
        document.getElementById('foundIdBox').classList.remove('hidden');
        document.getElementById('findIdEmailError').textContent = '';
    } else {
        document.getElementById('findIdEmailError').textContent = '등록되지 않은 이메일입니다.';
        document.getElementById('findIdSuccess').textContent = '';
        document.getElementById('foundIdBox').classList.add('hidden');
    }
}

// 비밀번호 찾기
function showForgotPassword() {
    document.getElementById('authContainer').classList.add('hidden');
    document.getElementById('forgotPasswordContainer').classList.remove('hidden');
    document.getElementById('forgotStep1').classList.remove('hidden');
    document.getElementById('forgotStep2').classList.add('hidden');
}

function handleForgotStep1(event) {
    event.preventDefault();

    const userId = document.getElementById('forgotId').value;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.userId === userId);

    if (user) {
        document.getElementById('resetId').value = userId;
        document.getElementById('forgotStep1').classList.add('hidden');
        document.getElementById('forgotStep2').classList.remove('hidden');
    } else {
        document.getElementById('forgotIdError').textContent = '등록되지 않은 아이디입니다.';
    }
}

function handleResetPassword(event) {
    event.preventDefault();

    const userId = document.getElementById('resetId').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (newPassword.length < 8) {
        document.getElementById('newPasswordError').textContent = '비밀번호는 8자 이상이어야 합니다.';
        return;
    }

    if (newPassword !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = '비밀번호가 일치하지 않습니다.';
        return;
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.userId === userId);

    if (userIndex !== -1) {
        users[userIndex].password = newPassword;
        localStorage.setItem('users', JSON.stringify(users));

        document.getElementById('resetSuccess').textContent = '✅ 비밀번호가 변경되었습니다!';

        setTimeout(() => {
            backToLogin();
        }, 1500);
    }
}

// 로그인 페이지로 돌아가기
function backToLogin() {
    document.getElementById('forgotPasswordContainer').classList.add('hidden');
    document.getElementById('findIdContainer').classList.add('hidden');
    document.getElementById('authContainer').classList.remove('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
    document.getElementById('signupForm').classList.add('hidden');
}

function handleChangeNickname(event) {
    event.preventDefault();

    const newNickname = document.getElementById('newNickname').value.trim();
    const nicknameError = document.getElementById('nicknameError');
    const nicknameSuccess = document.getElementById('nicknameSuccess');

    nicknameError.textContent = '';
    nicknameSuccess.textContent = '';

    if (newNickname.length < 2) {
        nicknameError.textContent = '닉네임은 2자 이상이어야 합니다.';
        return;
    }

    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const users = JSON.parse(localStorage.getItem('users') || '[]');

    if (!currentUser) {
        nicknameError.textContent = '로그인 정보가 없습니다.';
        return;
    }

    // ✅ 1) 먼저 PHP에 닉네임 변경 요청 보내기
    fetch('../update_nickname.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: currentUser.userId,     // username
            nickname: newNickname      // 새 닉네임
        })
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) {
            nicknameError.textContent = data.message || '닉네임 변경 중 오류가 발생했습니다.';
            return;
        }

        // ✅ 2) 서버에서 성공했다고 하면 localStorage도 업데이트
        const userIndex = users.findIndex(u => u.userId === currentUser.userId);
        if (userIndex !== -1) {
            users[userIndex].name = newNickname;
            currentUser.name = newNickname;

            localStorage.setItem('users', JSON.stringify(users));
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
        }

        // 화면 업데이트
        document.getElementById('displayUserName').textContent = newNickname;
        document.getElementById('infoName').textContent = newNickname;

        nicknameSuccess.textContent = '✅ 닉네임이 변경되었습니다!';

        setTimeout(() => {
            closeChangeNickname();
        }, 1500);
    })
    .catch(error => {
        console.error('닉네임 변경 오류:', error);
        nicknameError.textContent = '서버 오류로 닉네임을 변경할 수 없습니다.';
    });
}


// 프로필 이미지 관련 함수들 (기존 코드 재사용)
let signupProfileImage = null;

function handleSignupProfileImageChange(event) {
    const file = event.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) {
            alert('이미지 크기는 5MB 이하여야 합니다.');
            event.target.value = '';
            return;
        }

        if (!file.type.startsWith('image/')) {
            alert('이미지 파일만 업로드 가능합니다.');
            event.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            signupProfileImage = e.target.result;
            document.getElementById('signupProfilePreview').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

function handleProfileImageChange(event) {
    const file = event.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) {
            alert('이미지 크기는 5MB 이하여야 합니다.');
            event.target.value = '';
            return;
        }

        if (!file.type.startsWith('image/')) {
            alert('이미지 파일만 업로드 가능합니다.');
            event.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById('profilePreview').src = e.target.result;

            // 사용자 정보 업데이트
            const currentUser = JSON.parse(localStorage.getItem('currentUser'));
            const users = JSON.parse(localStorage.getItem('users') || '[]');

            const userIndex = users.findIndex(u => u.userId === currentUser.userId);
            if (userIndex !== -1) {
                users[userIndex].profileImage = e.target.result;
                currentUser.profileImage = e.target.result;

                localStorage.setItem('users', JSON.stringify(users));
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
            }
        };
        reader.readAsDataURL(file);
    }
}

// 페이지 로드 시 초기화
window.onload = async function () {
    // 저장된 아이디 불러오기
    const savedUserId = localStorage.getItem('savedUserId');
    if (savedUserId) {
        document.getElementById('loginId').value = savedUserId;
        document.getElementById('rememberMe').checked = true;
    }

    // 로그인 상태 확인
    const isLoggedIn = getCookie('loggedIn') === 'true';

    if (isLoggedIn) {
        try {
            // ✅ PHP 세션 확인
            const response = await fetch('../session.php');
            const data = await response.json();

            if (data.loggedIn) {
                // 세션 유효 - localStorage 확인
                const currentUser = JSON.parse(localStorage.getItem('currentUser'));
                if (currentUser) {
                    showMainPage();
                }
            } else {
                // 세션 만료 - 쿠키 삭제
                setCookie('loggedIn', '', -1);
                localStorage.removeItem('currentUser');
            }
        } catch (error) {
            console.error('세션 확인 오류:', error);
        }
    }
};