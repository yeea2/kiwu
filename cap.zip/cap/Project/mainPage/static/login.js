// 회원가입 폼의 프로필 이미지 변경 처리
let signupProfileImage = null; // 회원가입 시 선택된 프로필 이미지 저장

function handleSignupProfileImageChange(event) {
    const file = event.target.files[0];
    if (file) {
        // 파일 크기 체크 (5MB 제한)
        if (file.size > 5 * 1024 * 1024) {
            alert('이미지 크기는 5MB 이하여야 합니다.');
            event.target.value = '';
            return;
        }

        // 이미지 파일인지 확인
        if (!file.type.startsWith('image/')) {
            alert('이미지 파일만 업로드 가능합니다.');
            event.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            signupProfileImage = e.target.result; // Base64 이미지 저장
            document.getElementById('signupProfilePreview').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

// 기존 handleSignup 함수 수정 (프로필 이미지 포함)
function handleSignup(event) {
    event.preventDefault();
    
    // 이전 에러 메시지 초기화
    document.getElementById('signupIdError').textContent = '';
    document.getElementById('signupEmailError').textContent = '';
    document.getElementById('signupPasswordError').textContent = '';
    document.getElementById('signupPasswordConfirmError').textContent = '';
    
    const name = document.getElementById('signupName').value;
    const userId = document.getElementById('signupId').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const passwordConfirm = document.getElementById('signupPasswordConfirm').value;
    
    // 아이디 검증
    if (userId.length < 4) {
        document.getElementById('signupIdError').textContent = '아이디는 4자 이상이어야 합니다.';
        return;
    }
    
    // 비밀번호 검증
    if (password.length < 8) {
        document.getElementById('signupPasswordError').textContent = '비밀번호는 8자 이상이어야 합니다.';
        return;
    }
    
    if (password !== passwordConfirm) {
        document.getElementById('signupPasswordConfirmError').textContent = '비밀번호가 일치하지 않습니다.';
        return;
    }
    
    // 아이디 중복 체크
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.some(user => user.userId === userId)) {
        document.getElementById('signupIdError').textContent = '이미 사용 중인 아이디입니다.';
        return;
    }
    
    // 이메일 중복 체크
    if (users.some(user => user.email === email)) {
        document.getElementById('signupEmailError').textContent = '이미 등록된 이메일입니다.';
        return;
    }
    
    // 프로필 이미지가 없으면 기본 이미지 사용
    const profileImage = signupProfileImage || './images/profile.png';
    
    // 사용자 정보 저장
    const newUser = {
        name: name,
        userId: userId,
        email: email,
        password: password,
        profileImage: profileImage,
        joinDate: new Date().toISOString(),
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // 성공 메시지
    document.getElementById('signupSuccess').textContent = '✅ 회원가입이 완료되었습니다!';
    
    // 폼 초기화 및 로그인 페이지로 이동
    setTimeout(() => {
        document.getElementById('signupSuccess').textContent = '';
        event.target.reset();
        signupProfileImage = null; // 이미지 초기화
        document.getElementById('signupProfilePreview').src = './images/profile.png';
        switchForm();
    }, 1500);
}

// 로그인 처리
function handleLogin(event) {
    event.preventDefault();
    
    // 이전 에러 메시지 초기화
    document.getElementById('loginPasswordError').textContent = '';
    
    const userId = document.getElementById('loginId').value;
    const password = document.getElementById('loginPassword').value;
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.userId === userId && u.password === password);
    
    if (user) {
        // 로그인 성공
        localStorage.setItem('currentUser', JSON.stringify(user));
        document.getElementById('loginSuccess').textContent = '✅ 로그인 성공!';
        
        setTimeout(() => {
            showMainPage();
        }, 1000);
    } else {
        document.getElementById('loginPasswordError').textContent = '아이디 또는 비밀번호가 올바르지 않습니다.';
    }
}

// 메인 페이지 표시
function showMainPage() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (currentUser) {
        document.getElementById('authContainer').classList.add('hidden');
        document.getElementById('forgotPasswordContainer').classList.add('hidden');
        document.getElementById('mainPage').classList.remove('hidden');
        
        // 사용자 정보 표시
        document.getElementById('displayUserName').textContent = currentUser.name;
        document.getElementById('infoName').textContent = currentUser.name;
        document.getElementById('infoId').textContent = currentUser.userId;
        document.getElementById('infoEmail').textContent = currentUser.email;
        
        // 가입일 표시
        if (currentUser.joinDate) {
            const joinDate = new Date(currentUser.joinDate);
            document.getElementById('infoDate').textContent = joinDate.toLocaleDateString('ko-KR');
        }
    }
}

// 로그아웃
function logout() {
    localStorage.removeItem('currentUser');
    document.getElementById('mainPage').classList.add('hidden');
    document.getElementById('authContainer').classList.remove('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
    document.getElementById('signupForm').classList.add('hidden');
    
    // 폼 초기화
    document.getElementById('loginId').value = '';
    document.getElementById('loginPassword').value = '';
}

// 폼 전환
function switchForm() {
    document.getElementById('loginForm').classList.toggle('hidden');
    document.getElementById('signupForm').classList.toggle('hidden');
    
    // 에러 메시지 및 성공 메시지 초기화
    document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
    document.querySelectorAll('.success-message').forEach(el => el.textContent = '');
    
    // 입력 필드 초기화
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    if (loginForm && !loginForm.classList.contains('hidden')) {
        document.getElementById('loginId').value = '';
        document.getElementById('loginPassword').value = '';
    }
}

// 비밀번호 표시/숨김
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}

// 비밀번호 찾기
function showForgotPassword() {
    document.getElementById('authContainer').classList.add('hidden');
    document.getElementById('findIdContainer').classList.add('hidden');
    document.getElementById('forgotPasswordContainer').classList.remove('hidden');
    document.getElementById('forgotStep1').classList.remove('hidden');
    document.getElementById('forgotStep2').classList.add('hidden');
    
    // 폼 초기화
    document.getElementById('forgotId').value = '';
    document.getElementById('forgotIdError').textContent = '';
}

// 아이디 찾기
function showFindId() {
    document.getElementById('authContainer').classList.add('hidden');
    document.getElementById('forgotPasswordContainer').classList.add('hidden');
    document.getElementById('findIdContainer').classList.remove('hidden');
    
    // 폼 초기화
    document.getElementById('findIdEmail').value = '';
    document.getElementById('findIdEmailError').textContent = '';
    document.getElementById('findIdSuccess').textContent = '';
    document.getElementById('foundIdBox').classList.add('hidden');
}

// 아이디 찾기 처리
function handleFindId(event) {
    event.preventDefault();
    
    const email = document.getElementById('findIdEmail').value;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email);
    
    if (user) {
        // 아이디 찾기 성공
        document.getElementById('findIdSuccess').textContent = '✅ 아이디를 찾았습니다!';
        document.getElementById('foundIdValue').textContent = user.userId;
        document.getElementById('foundIdBox').classList.remove('hidden');
        document.getElementById('findIdEmailError').textContent = '';
    } else {
        // 아이디 찾기 실패
        document.getElementById('findIdEmailError').textContent = '등록되지 않은 이메일입니다.';
        document.getElementById('findIdSuccess').textContent = '';
        document.getElementById('foundIdBox').classList.add('hidden');
    }
}

function handleForgotStep1(event) {
    event.preventDefault();
    
    const userId = document.getElementById('forgotId').value;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.userId === userId);
    
    if (user) {
        document.getElementById('resetId').value = userId;
        document.getElementById('forgotStep1').classList.add('hidden');
        document.getElementById('forgotStep2').classList.remove('hidden');
    } else {
        document.getElementById('forgotIdError').textContent = '등록되지 않은 아이디입니다.';
    }
}

function handleResetPassword(event) {
    event.preventDefault();
    
    // 이전 에러 메시지 초기화
    document.getElementById('newPasswordError').textContent = '';
    document.getElementById('confirmPasswordError').textContent = '';
    
    const userId = document.getElementById('resetId').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword.length < 8) {
        document.getElementById('newPasswordError').textContent = '비밀번호는 8자 이상이어야 합니다.';
        return;
    }
    
    if (newPassword !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = '비밀번호가 일치하지 않습니다.';
        return;
    }
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.userId === userId);
    
    if (userIndex !== -1) {
        users[userIndex].password = newPassword;
        localStorage.setItem('users', JSON.stringify(users));
        
        document.getElementById('resetSuccess').textContent = '✅ 비밀번호가 변경되었습니다!';
        
        setTimeout(() => {
            backToLogin();
        }, 1500);
    }
}

function backToLogin() {
    document.getElementById('forgotPasswordContainer').classList.add('hidden');
    document.getElementById('findIdContainer').classList.add('hidden');
    document.getElementById('authContainer').classList.remove('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
    document.getElementById('signupForm').classList.add('hidden');
    
    // 폼 초기화
    document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
    document.querySelectorAll('.success-message').forEach(el => el.textContent = '');
}

// 닉네임 변경 모달
function showChangeNickname() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        document.getElementById('currentNickname').value = currentUser.name;
        document.getElementById('changeNicknameModal').classList.remove('hidden');
    }
}

function closeChangeNickname() {
    document.getElementById('changeNicknameModal').classList.add('hidden');
    document.getElementById('newNickname').value = '';
    document.getElementById('nicknameError').textContent = '';
    document.getElementById('nicknameSuccess').textContent = '';
}

function handleChangeNickname(event) {
    event.preventDefault();
    
    const newNickname = document.getElementById('newNickname').value.trim();
    
    if (newNickname.length < 2) {
        document.getElementById('nicknameError').textContent = '닉네임은 2자 이상이어야 합니다.';
        return;
    }
    
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    const userIndex = users.findIndex(u => u.userId === currentUser.userId);
    if (userIndex !== -1) {
        users[userIndex].name = newNickname;
        currentUser.name = newNickname;
        
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        document.getElementById('nicknameSuccess').textContent = '✅ 닉네임이 변경되었습니다!';
        
        // 화면 업데이트
        document.getElementById('displayUserName').textContent = newNickname;
        document.getElementById('infoName').textContent = newNickname;
        
        setTimeout(() => {
            closeChangeNickname();
        }, 1500);
    }
}

// 프로필 이미지 변경 (기존 모달용)
function handleProfileImageChange(event) {
    const file = event.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) {
            alert('이미지 크기는 5MB 이하여야 합니다.');
            event.target.value = '';
            return;
        }

        if (!file.type.startsWith('image/')) {
            alert('이미지 파일만 업로드 가능합니다.');
            event.target.value = '';
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profilePreview').src = e.target.result;
            
            // 사용자 정보 업데이트
            const currentUser = JSON.parse(localStorage.getItem('currentUser'));
            const users = JSON.parse(localStorage.getItem('users') || '[]');
            
            const userIndex = users.findIndex(u => u.userId === currentUser.userId);
            if (userIndex !== -1) {
                users[userIndex].profileImage = e.target.result;
                currentUser.profileImage = e.target.result;
                
                localStorage.setItem('users', JSON.stringify(users));
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
            }
        };
        reader.readAsDataURL(file);
    }
}

// 페이지 로드 시 로그인 상태 확인
window.onload = function() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        showMainPage();
    }
};