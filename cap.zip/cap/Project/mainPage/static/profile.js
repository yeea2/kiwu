let currentUser = null;
let registeredUsers = {};

// 페이지 로드 시 사용자 정보 불러오기
window.addEventListener('DOMContentLoaded', function() {
    loadUserData();
    if (!currentUser) {
        alert('로그인이 필요합니다');
        window.location.href = './login.html';
    }
});

// 사용자 데이터 불러오기
function loadUserData() {
    const savedUser = localStorage.getItem('currentUser');
    const savedUsers = localStorage.getItem('registeredUsers');
    
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
    }
    if (savedUsers) {
        registeredUsers = JSON.parse(savedUsers);
    }
    
    // 프로필 정보 표시
    if (currentUser) {
        document.getElementById('currentNickname').value = currentUser.name;
        
        const savedProfileImage = localStorage.getItem('profileImage_' + currentUser.email);
        if (savedProfileImage) {
            document.getElementById('profilePreview').src = savedProfileImage;
        }
    }
}

// 비밀번호 표시/숨김 토글
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const button = event.target.closest('.password-toggle');
    
    if (input.type === 'password') {
        input.type = 'text';
        button.textContent = '🙈';
    } else {
        input.type = 'password';
        button.textContent = '👁️';
    }
}

// 프로필 이미지 변경
function handleProfileImageChange(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
        alert('파일 크기는 5MB 이하여야 합니다');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const base64Image = e.target.result;
        document.getElementById('profilePreview').src = base64Image;
        document.getElementById('profileImageInput').dataset.newImage = base64Image;
    };
    reader.readAsDataURL(file);
}

// 프로필 이미지 저장
function saveProfileImage() {
    const newImage = document.getElementById('profileImageInput').dataset.newImage;
    
    if (!newImage) {
        alert('변경된 이미지가 없습니다');
        return;
    }
    
    localStorage.setItem('profileImage_' + currentUser.email, newImage);
    
    const successMsg = document.getElementById('imageSuccess');
    successMsg.textContent = '✓ 프로필 이미지가 저장되었습니다!';
    successMsg.classList.add('show');
    
    document.getElementById('profileImageInput').value = '';
    document.getElementById('profileImageInput').dataset.newImage = '';
    
    setTimeout(() => {
        successMsg.classList.remove('show');
    }, 2000);
}

// 닉네임 변경
function handleChangeNickname(event) {
    event.preventDefault();
    
    const newNickname = document.getElementById('newNickname').value.trim();
    const nicknameError = document.getElementById('nicknameError');
    const nicknameSuccess = document.getElementById('nicknameSuccess');
    
    nicknameError.classList.remove('show');
    nicknameSuccess.classList.remove('show');
    
    if (newNickname.length < 2) {
        nicknameError.textContent = '닉네임은 2자 이상이어야 합니다';
        nicknameError.classList.add('show');
        return;
    }
    
    if (newNickname.length > 15) {
        nicknameError.textContent = '닉네임은 15자 이하여야 합니다';
        nicknameError.classList.add('show');
        return;
    }
    
    if (newNickname === currentUser.name) {
        nicknameError.textContent = '기존 닉네임과 같습니다';
        nicknameError.classList.add('show');
        return;
    }
    
    const email = currentUser.email;
    registeredUsers[email].name = newNickname;
    currentUser.name = newNickname;
    
    localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    document.getElementById('currentNickname').value = newNickname;
    
    nicknameSuccess.textContent = '✓ 닉네임이 저장되었습니다!';
    nicknameSuccess.classList.add('show');
    
    document.getElementById('newNickname').value = '';
    
    setTimeout(() => {
        nicknameSuccess.classList.remove('show');
    }, 2000);
}

// 비밀번호 변경
function handleChangePassword(event) {
    event.preventDefault();
    
    const email = currentUser.email;
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    const currentPasswordError = document.getElementById('currentPasswordError');
    const newPasswordError = document.getElementById('newPasswordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const passwordSuccess = document.getElementById('passwordSuccess');
    
    currentPasswordError.classList.remove('show');
    newPasswordError.classList.remove('show');
    confirmPasswordError.classList.remove('show');
    passwordSuccess.classList.remove('show');
    
    if (registeredUsers[email].password !== currentPassword) {
        currentPasswordError.textContent = '현재 비밀번호가 일치하지 않습니다';
        currentPasswordError.classList.add('show');
        return;
    }
    
    if (newPassword.length < 8) {
        newPasswordError.textContent = '새 비밀번호는 8자 이상이어야 합니다';
        newPasswordError.classList.add('show');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        confirmPasswordError.textContent = '새 비밀번호가 일치하지 않습니다';
        confirmPasswordError.classList.add('show');
        return;
    }
    
    if (currentPassword === newPassword) {
        newPasswordError.textContent = '현재 비밀번호와 같습니다';
        newPasswordError.classList.add('show');
        return;
    }
    
    registeredUsers[email].password = newPassword;
    localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
    
    passwordSuccess.textContent = '✓ 비밀번호가 변경되었습니다!';
    passwordSuccess.classList.add('show');
    
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
    
    setTimeout(() => {
        passwordSuccess.classList.remove('show');
    }, 2000);
}

// 메인으로 돌아가기
function goBackToMain() {
    window.location.href = './login.html';
}

// 로그아웃
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = './login.html';
}