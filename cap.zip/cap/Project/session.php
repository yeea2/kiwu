
<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    echo json_encode([
        'loggedIn' => true,
        'userId'   => $_SESSION['username']  // 👈 JS 에서 sessionData.userId 로 받음
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['loggedIn' => false], JSON_UNESCAPED_UNICODE);
}
