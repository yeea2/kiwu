<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

// 1. DB 연결
$host = 'localhost';
$user = 'root';    // phpMyAdmin 아이디
$pass = '';        // 비밀번호 있으면 입력
$db   = 'capstone';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'DB 연결 실패: ' . $conn->connect_error],
                     JSON_UNESCAPED_UNICODE);
    exit;
}

// 2. JS에서 보낸 JSON 읽기
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

$id = isset($data['id']) ? trim($data['id']) : '';
$pw = isset($data['pw']) ? trim($data['pw']) : '';

if ($id === '' || $pw === '') {
    echo json_encode(['success' => false, 'message' => '아이디와 비밀번호를 모두 입력해주세요.'],
                     JSON_UNESCAPED_UNICODE);
    exit;
}

// 3. DB에서 아이디/비밀번호 확인
$stmt = $conn->prepare("SELECT id FROM members WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $id, $pw);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows === 1) {
    $_SESSION['logged_in'] = true;
    $_SESSION['username']  = $id;

    echo json_encode(['success' => true, 'message' => '로그인 성공'],
                     JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['success' => false, 'message' => '아이디 또는 비밀번호가 올바르지 않습니다.'],
                     JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
